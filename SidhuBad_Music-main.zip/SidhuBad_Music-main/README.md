<h2 align="center">
    ─「 sᴘᴏᴛɪғʏ ᴍᴜsɪᴄ 」─

</h2>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=ㅤ+𝚆𝙴𝙻𝙲𝙾𝙼𝙴+𝚃𝙾+sᴘᴏᴛɪғʏ+𝙼𝚄𝚂𝙸𝙲+𝚁𝙴𝙿𝙾+;ㅤ+𝚃𝙷𝙸𝚂+𝙸𝚂+𝙰+𝙰𝙳𝚅𝙰𝙽𝙲𝙴+𝙼𝚄𝚂𝙸𝙲+𝙱𝙾𝚃;𝙿𝙾𝚆𝙴𝚁𝙴𝙳+𝙱𝚈+☞+ʙᴀᴅ+ᴍᴜɴᴅᴀ)](https://github.com/Badhacker98/Spotify_Music)



<p align="center">
  <img src="https://telegra.ph/file/41fb87a04991c7de081c3.jpg">
</p>



![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=𝗙𝗢𝗥𝗞+𝗧𝗛𝗜𝗦+𝗥𝗘𝗣𝗢+𝗕𝗘𝗙𝗢𝗥𝗘+𝗗𝗘𝗣𝗟𝗢𝗬)

## ⚠️ 𝗗𝗜𝗦𝗖𝗟𝗔𝗜𝗠𝗘𝗥
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👉🏻 ʜᴇʏ ɢᴜʏ's, ᴅᴏɴ'ᴛ ᴜsᴇ ʏᴏᴜʀ ʀᴇᴀʟ ɪ'ᴅ sᴇssɪᴏɴ ᴀs ᴀ ᴀssɪsᴛᴀɴᴛ ʙᴄᴏᴢ ᴛʜᴇ ᴀssɪsᴛᴀɴᴛ ᴡɪʟʟ ʟᴇᴀᴠᴇ ᴀʟʟ ᴛʜᴇ ɢʀᴏᴜᴘs & ᴄʜᴀɴɴᴇʟs.ᴜ  ᴍɪɢʜᴛ ʟᴏᴏsᴇ ʏᴏᴜʀ ɢʀᴏᴜᴘs ᴏᴡɴᴇʀsʜɪᴘ ᴀɴᴅ ᴀᴅᴍɪɴsʜɪᴘ 🥺 sᴏ ᴜsᴇ ʏᴏᴜʀ ᴀɴʏ ᴏᴛʜᴇʀ ɪ'ᴅ sᴇssɪᴏɴ 👈🏻
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


## 🖇 Generating Pyrogram String Session

<p>
<a href="https://t.me/Gaana_MusicBot"><img src="https://img.shields.io/badge/DEMO%20BOT-blueviolet?style=for-the-badge&logo=appveyor" width="200""/></a>
<a href="https://t.me/ll_BAD_MUNDA_ll"><img src="https://img.shields.io/badge/DM%20TO%20BADMUNDA-blueviolet?style=for-the-badge&logo=appveyor" width="200""/></a>

# 𝗗𝗘𝗣𝗟𝗢𝗬 𝗢𝗡 𝗛𝗘𝗥𝗢𝗞𝗨
<p align="center"><a href="http://dashboard.heroku.com/new?template=https://github.com/Badhacker98/Spotify_Music"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-greenviolet?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

---
# HOST ON VPS 

1.
```
apt install sudo screen -y
```

2.
```
sudo apt update && sudo apt install git curl python3-pip ffmpeg -y
```

3.
```
curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash
```

4.
```
source ~/.bashrc
```

5.
```
nvm install node
```

6.
```
sudo apt-get update && sudo apt-get upgrade -y
```

7.
```
sudo apt-get install python3-pip ffmpeg -y
```

8.
```
sudo apt-get install python3-pip -y
```

9.
```
sudo pip3 install -U pip
```

10.
```
curl -fssL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm
```

11.
```
git clone https://github.com/Badhacker98/Spotify_Music && cd Spotify_Music
```

12.
```
pip3 install -U -r requirements.txt
```

13.
```
sudo apt install tmux && tmux
```

14.
```
apt install nano
```

15.
```
sudo bash setup
```

16.
```
screen -R Spotify_Music
```

17.
```
bash start
```

18.
```
ctrl + a+d
```
---

### Contact :
<a href="https://t.me/ll_BAD_MUNDA_ll"><img title="Telegram" src="https://img.shields.io/badge/Telegram-%23000000.svg?&style=for-the-badge&logo=telegram&logoColor=61DAFB"></a>
<a href="https://mail.google.com/mail/?view=cm&fs=1&to=sukhwinderwarval50@gmail.com"><img title="GMAIL" src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white"></a>
<a href="https://instagram.com/lll_bad_munda_lll"><img title="Instagram" src="https://img.shields.io/badge/instagram-%23E4405F.svg?&style=for-the-badge&logo=instagram&logoColor=white"></a>
