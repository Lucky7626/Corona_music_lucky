<h2 align="center">
    「 ❣️ʙᴀᴅ ᴍᴜsɪᴄ ❣️ 」
</h2>
<a href="https://youtu.be/0hP_JY_APq0?si=md6qsZQP2UaQ-SPn"><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>

<p align="center"><a href="https://t.me/II_BAD_BBY_II"><img src="https://telegra.ph/file/3df11bcade4a69a6335f2.jpg"></a></p>

<a href="https://youtu.be/0hP_JY_APq0?si=md6qsZQP2UaQ-SPn"><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>


        •━━━━━━━━•••━━━━━━━━•

<img src="https://readme-typing-svg.herokuapp.com?color=FF0000&width=420&lines=MADE+BYE+BADMUNDA%E2%9D%A4%EF%B8%8F"> 

        •━━━━━━━━•••━━━━━━━━•


<h3 align="center">
    ─「 ❣👇sᴘᴇᴄɪᴀʟ❣️ᴛᴀɢᴀʟʟ👇 」─   
</h3>

<h3 align="center">
    ─「 ❣️ᴛᴇʟᴇɢʀᴀᴘʜ ʟɪɴᴋ❣️ 」─   
</h3>

<h3 align="center">
    ─「 ❣️ʙᴀss sᴏɴɢ❣️ 」─   
</h3>

<h3 align="center">
    ─「 ❣️sʜᴀʏᴀʀɪ❣️ 」─   
</h3>
